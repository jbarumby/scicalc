# NUMERIA — E7 revisão formal

**Executar no Windows, sem BAT**. Esta revisão usa apenas a biblioteca padrão do Python 3.10+ e **não substitui os arquivos de fases anteriores**.

Após extrair o ZIP em `%USERPROFILE%\Downloads\NUMERIA_E7`, execute no CMD:

```bat
python "%USERPROFILE%\Downloads\NUMERIA_E7\REVISOR_E7.py" --out "%USERPROFILE%\Downloads\NUMERIA_E7\RESULTADO_E7_WINDOWS.json"
python "%USERPROFILE%\Downloads\NUMERIA_E7\VERIFICAR_EM_FASE4_E7.py"
python "%USERPROFILE%\Downloads\NUMERIA_E7\GERAR_CERTIFICADOS_E7.py" --out "%USERPROFILE%\Downloads\NUMERIA_E7\RESULTADO_INTEGRAIS_WINDOWS.json"
python "%USERPROFILE%\Downloads\NUMERIA_E7\TESTAR_REVISOR_E7.py"
python "%USERPROFILE%\Downloads\NUMERIA_E7\VERIFICAR_MANIFESTO_E7.py"
```

Status esperado: **16/16 verificações**, **15/15 testes EM**, **15.754 pontos**, **100 raios** e **6/6 adulterações rejeitadas**.

O resultado é CONDICIONAL à correção matemática dos lemas e da implementação de intervalos, e não prova a Hipótese de Riemann.
