"""Pesos e majorante analítico, só Fraction — sem flint, sem mpmath.

Fórmulas auditadas na Fase 3; cópia autônoma para a Fase 4.
"""
from fractions import Fraction as Q
from functools import lru_cache

@lru_cache(maxsize=None)
def pesos_interpolatorios(m):
    if not 2 <= m <= 24: raise ValueError('2 <= m <= 24')
    nodes=[Q(j,m-1) for j in range(m)]
    mat=[[nodes[j]**k for j in range(m)] + [Q(1,k+1)] for k in range(m)]
    for k in range(m):
        pivot=next((t for t in range(k,m) if mat[t][k]),None)
        if pivot is None: raise ArithmeticError('Vandermonde singular')
        mat[k],mat[pivot]=mat[pivot],mat[k]
        d=mat[k][k]
        mat[k]=[z/d for z in mat[k]]
        for r in range(m):
            if r!=k:
                fac=mat[r][k]
                if fac: mat[r]=[a-fac*b for a,b in zip(mat[r],mat[k])]
    weights=tuple(row[-1] for row in mat)
    for k in range(m):
        if sum(weights[j]*nodes[j]**k for j in range(m))!=Q(1,k+1):
            raise AssertionError('identidade dos momentos falhou')
    return weights

@lru_cache(maxsize=None)
def produto_maximo_conservador(m):
    p=Q(1)
    for j in range(m):
        u=Q(j,m-1);p*=max(u,1-u)
    return p

def majorante_analitico_racional(L,centro,h,rho):
    L,centro,h,rho=map(Q,(L,centro,h,rho))
    d=rho+h/2
    alpha=Q(1,4)-d/2
    if not (L>0 and h>0 and rho>0 and alpha>0 and 2*L*d<1):
        raise ValueError('hipóteses do majorante não satisfeitas')
    return (4*L/(3*(1-2*L*d)))*(3+(1+1/alpha)*(1+(abs(centro)+d)/2))
