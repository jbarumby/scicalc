#!/usr/bin/env python3
"""NUMERIA B3 extension: paridade exata G12, enclosures racionais de G22.

Sem Arb/mpmath para a prova computacional. Importa apenas os auxiliares
racionais da auditoria B3 G11 e nao importa o integrador de producao.
"""
from __future__ import annotations
import argparse, json, math, time
from fractions import Fraction as F
from pathlib import Path
import AUDITOR_G11_B3 as b


def sin_bound_for_r(r, order=40):
    """Seno com reducao angular intervalar e Taylor com resto <= 4^(2m+3)/(2m+3)!."""
    x=b.L*F(r)
    k=int(round(float(x)/(2*math.pi))) # indice candidato; aceito somente apos verificacao exata
    t=b.IV.f(x)-b.IV.f(2*k)*b.PI
    if t.abs_upper()>=4:
        raise ArithmeticError('reducao angular fora da faixa demonstrada')
    t2=t.sq();term=t;acc=term
    for j in range(1,order+1):
        term=term*(-t2)/b.IV.f((2*j)*(2*j+1))
        acc+=term
    eps=F(4)**(2*order+3)/F(math.factorial(2*order+3))
    r=b.IV.f(eps)
    return b.IV(acc.lo-r.hi,acc.hi+r.hi)


def a2_square_at_r(r):
    r=F(r)
    D=b.IV.f(r*r)-b.PI.sq()/b.IV.f(b.L*b.L)
    if D.lo<=0<=D.hi:raise ArithmeticError('polo removivel na razao: use representacao regularizada')
    return b.IV.f(4)*b.PI.sq()*sin_bound_for_r(r).sq()/(b.IV.f(b.L**3)*D.sq())


def integrand22_at_r(r):
    return a2_square_at_r(r)*b.omega_at_r(r)/b.PI


def band_m2_22(left,right):
    l=F(left);h=F(right)
    omega_abs=max(b.omega_at_r(l).abs_upper(),b.omega_at_r(h).abs_upper())
    od1,od2=b.upper_omega_derivs(l,h)
    if h<=12:
        a0=2*b.SQRTL_HI
        a1=b.SQRTL_HI*b.L
        a2=F(2,3)*b.SQRTL_HI*b.L**2
    else:
        if l<12:raise ValueError('faixa cruza o polo de Fourier')
        w2=b.PI_HI**2/(b.L*b.L)
        D=l*l-w2
        if D<=0:raise ArithmeticError('banda deve estar alem do polo')
        C=2*b.PI_HI/(b.L*b.SQRTL_LO)
        a0=C/D
        a1=C*(b.L/D+2*h/D**2)
        a2=C*(b.L*b.L/D+4*b.L*h/D**2+2/D**2+8*h*h/D**3)
    m2=((2*a1*a1+2*a0*a2)*omega_abs+4*a0*a1*od1+a0*a0*od2)/b.PI_LO
    return m2,{'omega_abs_upper':omega_abs,'omega_prime_abs_upper':od1,
              'omega_double_prime_abs_upper':od2,'F0_upper':a0,'F1_upper':a1,'F2_upper':a2}


def tail22_bound():
    _,loghi=b.logR_bounds()
    K=1-b.PI_HI**2/(b.L*b.L*b.R*b.R)
    if K<=0:raise ArithmeticError('cota de cauda sem denominador positivo')
    return 4*b.PI_HI*(6+loghi+F(1,3))/(3*b.L**3*b.R**3*K**2)


def verify_reference(reference, lo, hi):
    data=json.loads(Path(reference).read_text(encoding='utf-8'))
    p=data['parameters']
    if F(p['L'])!=b.L or F(p['R'])!=b.R or int(p['N'])<2:
        raise ValueError('parametros L,R,N incompativeis')
    G=data['archimedean_entry_enclosures']
    g12=G[0][1];g22=G[1][1]
    z=(F(g12['lower'])==0 and F(g12['upper'])==0)
    c=F(g22['lower'])<=lo and hi<=F(g22['upper'])
    return {'filename':Path(reference).name,'sha256':b.sha(Path(reference)),
            'parity_g12_zero_in_interval':z,'g22_inside_reference':c,
            'reference_g22':[g22['lower'],g22['upper']]}


def run(references,output,goal,verbose):
    t0=time.monotonic()
    if goal<=0:raise ValueError('erro-alvo deve ser positivo')
    if not (b.OMEGA0.lo<0 and b.OMEGA0.hi<0 and b.OMEGA0.lo>b.IV.f(-6).hi):
        raise ArithmeticError('constante Omega(0) fora da faixa usada na cauda')
    if not (b.PI_LO>3 and b.PI_HI<4):
        raise ArithmeticError('cotas de pi invalidas')
    bands=[(F(0),F(12)),(F(12),F(24)),(F(24),F(48)),(F(48),F(96)),(F(96),b.R)]
    mesh=build_mesh22(bands,goal)
    print('[NUMERIA B3] G12=0 por paridade exata (Fourier real x imaginaria)',flush=True)
    print('[NUMERIA B3] Malha G22: '+', '.join('%s-%s:%s'%(x['a'],x['b'],x['n']) for x in mesh),flush=True)
    sum_iv=b.IV.f(0);quadrature_error=F(0)
    for band in mesh:
        a,z,n=band['a'],band['b'],band['n'];h=(z-a)/n
        part=b.IV.f(0)
        for j in range(n):
            mid=a+(2*j+1)*h/2
            part+=integrand22_at_r(mid)*b.IV.f(h)
        sum_iv+=part;quadrature_error+=band['error']
        if verbose:print('[NUMERIA B3] banda %s-%s, %d celulas, erro <=%.8g'%(a,z,n,float(band['error'])),flush=True)
    # E2: o total deve majorar a soma das cotas por faixa JA arredondadas.
    rounded_band_error_sum=sum((F(b.IV.f(band['error']).hi,b.SCALE) for band in mesh),F(0))
    error_export=max(quadrature_error,rounded_band_error_sum)
    e=b.IV.f(error_export)
    finite=b.IV(sum_iv.lo-e.hi,sum_iv.hi+e.hi)
    tail=b.IV.f(tail22_bound())
    total=b.IV(finite.lo-tail.hi,finite.hi+tail.hi)
    lo,hi=total.as_fraction()
    checks=[verify_reference(p,lo,hi) for p in references]
    passed=bool(checks) and all(x['parity_g12_zero_in_interval'] and x['g22_inside_reference'] for x in checks)
    report={
      'schema':'NUMERIA.B3.G12G22.RATIONAL.1',
      'scope':'G12 paridade exata e G22 integral arquimediana, L=9/20,R=160, sem Arb',
      'method':'even-odd Fourier parity; midpoint rational directed intervals, second-derivative and tail bounds',
      'implementation_source_sha256':b.sha(Path(__file__)),'shared_G11_helpers_sha256':b.sha(Path(b.__file__)),
      'G12_exact_zero':True,'G22_fixed_point_midpoint':[b.jsonf(v) for v in sum_iv.as_fraction()],
      'G22_quadrature_error_upper':b.json_upper(error_export),
      'G22_tail_error_upper':b.json_upper(tail22_bound()),
      'G22_enclosure':[b.jsonf(lo),b.jsonf(hi)],
      'mesh':[{'from':str(x['a']),'to':str(x['b']),'cells':x['n'],
               'f2_bound':b.json_upper(x['m2']), 'error_bound':b.json_upper(x['error'])} for x in mesh],
      'references':checks,'all_references_passed':passed,
      'elapsed_seconds':round(time.monotonic()-t0,3),
      'limitations':['Extensao depende da auditoria dos limites auxiliares da B3 G11.',
                     'Sem auditoria externa do codigo/derivadas. Apenas entradas G12 e G22.',
                     'Nao valida formula explicita global nem todos os termos de Weil.']}
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print('[NUMERIA B3] G22 pertence a [%.15g,%.15g]'%(float(lo),float(hi)),flush=True)
    print('[NUMERIA B3] Erro quadratura <=%.9g; cauda <=%.9g'%(float(error_export),float(tail22_bound())),flush=True)
    print('[NUMERIA B3] Referencias %d/%d; relatorio %s'%(sum(x['g22_inside_reference'] for x in checks),len(checks),output),flush=True)
    return 0 if passed else 2


def build_mesh22(bands,goal):
    budgets=[]
    for a,z in bands:
        m2,diag=band_m2_22(a,z)
        c=m2*(z-a)**3/24
        budgets.append((c,diag,m2))
    weights=[float(c)**(F(1,3)) for c,_,_ in budgets]
    total=sum(weights)
    out=[]
    for (a,z),(c,diag,m2),weight in zip(bands,budgets,weights):
        E=goal*F.from_float(weight/total)
        n=max(1,math.ceil(math.sqrt(float(c/E))))
        while c/(n*n)>E:n+=1
        out.append({'a':a,'b':z,'n':n,'error':c/(n*n),'m2':m2,'diagnostics':diag})
    return out


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--references',type=Path,required=True,help='pasta de 9 JSON')
    p.add_argument('--output',type=Path,default=Path('RESULTADO_B3_G12_G22.json'))
    p.add_argument('--error-budget',default='0.00001')
    p.add_argument('--verbose',action='store_true')
    args=p.parse_args()
    refs=sorted(args.references.glob('*.json'))
    if len(refs)!=9:raise ValueError('esperadas 9 referencias JSON, recebidas '+str(len(refs)))
    expected={(t,n) for t in ('historico_192_tol50','historico_256_tol70','controle_256_tol50') for n in (6,8,10)}
    observed=set()
    for ref in refs:
        data=json.loads(ref.read_text(encoding='utf-8'))
        p=data['parameters']
        name=ref.stem
        if '_N' not in name:raise ValueError('nome de referencia desconhecido: '+name)
        tag,nstr=name.rsplit('_N',1)
        if not nstr.isdigit():raise ValueError('N invalido: '+name)
        n=int(nstr)
        if (tag,n) not in expected:raise ValueError('referencia inesperada: '+name)
        bits,tol=(192,50) if tag=='historico_192_tol50' else ((256,70) if tag=='historico_256_tol70' else (256,50))
        if (int(p['N'])!=n or int(p['arb_precision_bits'])!=bits or
            int(p['integral_tol_bits'])!=tol or p.get('archimedean')!='adaptive'):
            raise ValueError('parametros incompativeis com o nome: '+name)
        observed.add((tag,n))
    if observed!=expected:raise ValueError('faltam configuracoes distintas')
    return run(refs,args.output,F(args.error_budget),args.verbose)

if __name__=='__main__':raise SystemExit(main())
