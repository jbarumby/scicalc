#!/usr/bin/env python3
"""NUMERIA B5: envoltorios para TODOS os pontos medios, sem Arb/mpmath.

Usa inteiros de ponto fixo com arredondamento para fora, series trigonometricas
com restos de Taylor, serie convergente da digama e cauda por integral.
A certificacao vale para a SOMA FINITA dos pontos medios, condicionada a
identidades matematicas e aos restos demonstrados em AUDITORIA_B5.md.

Nao valida automaticamente o erro da regra do ponto medio, a cauda integral
[160,+infinito), ou a formula explicita de Weil.
"""
import argparse, hashlib, json, math, time
from fractions import Fraction as Q
from pathlib import Path

S=10**42
L=Q(9,20)
SERIES=128

def ceildiv(a,b):
    if b<=0:raise ValueError('denominador invalido')
    return -((-a)//b)

class I:
    __slots__=('a','b')
    def __init__(self,a,b=None):
        self.a=int(a);self.b=int(a if b is None else b)
        if self.a>self.b:raise ValueError('intervalo invertido')
    @staticmethod
    def q(q):
        q=Q(q)
        return I(q.numerator*S//q.denominator,ceildiv(q.numerator*S,q.denominator))
    def __add__(self,y):
        y=co(y);return I(self.a+y.a,self.b+y.b)
    __radd__=__add__
    def __neg__(self):return I(-self.b,-self.a)
    def __sub__(self,y):return self+-co(y)
    def __rsub__(self,y):return co(y)+-self
    def __mul__(self,y):
        y=co(y)
        vals=(self.a*y.a,self.a*y.b,self.b*y.a,self.b*y.b)
        return I(min(vals)//S,ceildiv(max(vals),S))
    __rmul__=__mul__
    def reciprocal(self):
        if self.a<=0<=self.b:raise ZeroDivisionError('reciproco de intervalo contendo zero')
        if self.b<0:return -(-self).reciprocal()
        return I((S*S)//self.b,ceildiv(S*S,self.a))
    def __truediv__(self,y):return self*co(y).reciprocal()
    def __rtruediv__(self,y):return co(y)*self.reciprocal()
    def sq(self):
        if self.a<=0<=self.b:return I(0,ceildiv(max(self.a**2,self.b**2),S))
        return I(min(self.a**2,self.b**2)//S,ceildiv(max(self.a**2,self.b**2),S))
    def absmax(self):return Q(max(abs(self.a),abs(self.b)),S)
    def midpoint_float(self):return (self.a+self.b)/(2*S)
    def pretty(self):return [str(Q(self.a,S)),str(Q(self.b,S))]

def co(x):return x if isinstance(x,I) else I.q(x)

def atan_q(x,n):
    x=Q(x); val=Q(0)
    for k in range(n): val+=(-1)**k * x**(2*k+1)/Q(2*k+1)
    rem=x**(2*n+1)/Q(2*n+1)
    return (val,val+rem) if n%2==0 else (val-rem,val)

# ln 2 independent via integral of geometric series
qq=Q(1,3)
ln2sum=2*sum((qq**(2*j+1)/Q(2*j+1) for j in range(95)),Q(0))
LN2_LO=ln2sum
LN2_HI=ln2sum+2*qq**191/Q(191)/(1-qq*qq)

def positive_log(x,n=90):
    x=Q(x)
    if x<=0:raise ValueError('log nao positivo')
    k=0
    while x>=2:x/=2;k+=1
    while x<1:x*=2;k-=1
    t=(x-1)/(x+1);p=t;z=Q(0)
    for j in range(n):
        z+=2*p/Q(2*j+1);p*=t*t
    rem=2*p/Q(2*n+1)/(1-t*t)
    if k>=0:return z+k*LN2_LO,z+rem+k*LN2_HI
    return z+k*LN2_HI,z+rem+k*LN2_LO

def pi_bounds():
    a=atan_q(Q(1,5),75);b=atan_q(Q(1,239),40)
    return 16*a[0]-4*b[1],16*a[1]-4*b[0]

PLO,PHI=pi_bounds()
PI=I(I.q(PLO).a,I.q(PHI).b)

def gamma_bounds():
    N=64
    H=sum((Q(1,k) for k in range(1,N+1)),Q(0))
    B=[Q(1,6),-Q(1,30),Q(1,42),-Q(1,30),Q(5,66),-Q(691,2730),Q(7,6),-Q(3617,510)]
    z=H-Q(1,2*N)
    corr=[B[i]/Q(2*(i+1)*N**(2*i+2)) for i in range(8)]
    upper=z+sum(corr[:7]);lower=upper+corr[7]
    return lower-6*LN2_HI,upper-6*LN2_LO

GLO,GHI=gamma_bounds()
loglo,loghi=positive_log((PLO+PHI)/2,120)
slack=(PHI-PLO)/(2*PLO)
LNPI=I(I.q(loglo-slack).a,I.q(loghi+slack).b)
OMEGA_ZERO=-(I(I.q(GLO).a,I.q(GHI).b))-PI/I.q(2)-I.q(3)*I(I.q(LN2_LO).a,I.q(LN2_HI).b)-LNPI

# Directed trigonometric Taylor polynomials, |reduced x| <= 4.
# Horner evaluation avoids dependence on magnitudes from repeated powers.

def reduced_angle(x):
    # Float only selects a candidate k; interval verifies |x-2k*pi|<4.
    k=round(x.midpoint_float()/(2*math.pi))
    t=x-I.q(2*k)*PI
    if t.absmax()>=4:raise ArithmeticError('falha da reducao de argumento')
    return t

def trig(x,kind,terms=36):
    x=reduced_angle(x);xx=-x.sq()
    if kind=='cos':
        v=I.q(1)
        for j in range(terms,0,-1):v=I.q(1)+xx*v/I.q((2*j)*(2*j-1))
        # The loop above computes 1 + x²/(2!)*(1+x²/(3*4)...)
        remainder=Q(4)**(2*terms+2)/math.factorial(2*terms+2)
    else:
        v=I.q(1)
        for j in range(terms,0,-1):v=I.q(1)+xx*v/I.q((2*j)*(2*j+1))
        v=x*v
        remainder=Q(4)**(2*terms+3)/math.factorial(2*terms+3)
    eps=I.q(remainder)
    return I(v.a-eps.b,v.b+eps.b)


def sinc_near(x,terms=32):
    if x.absmax()>=3:raise ValueError('Taylor sinc requer |x|<3')
    sq=-x.sq();z=I.q(1)
    for j in range(terms,0,-1):z=I.q(1)+sq*z/I.q((2*j)*(2*j+1))
    # sinc(x) terms 0..terms => first neglected order 2*terms+2
    rem=Q(3)**(2*terms+2)/math.factorial(2*terms+3)
    e=I.q(rem)
    return I(z.a-e.b,z.b+e.b)


def log1p_small(t,terms=48):
    """t>=0; log(1+t) = 2 sum q^(2n+1)/(2n+1), q=t/(2+t)."""
    if t.a<0:raise ValueError('log1p apenas para t>=0')
    q=t/(I.q(2)+t)
    if q.b>=S:raise ValueError('q deve ser menor que 1')
    q2=q.sq();v=I.q(0);p=q
    for j in range(terms):
        v+=I.q(2)*p/I.q(2*j+1)
        p=p*q2
    qmax=q.absmax()
    rem=2*qmax**(2*terms+1)/(Q(2*terms+1)*(1-qmax*qmax))
    return I(v.a,v.b+I.q(rem).b)


def omega(r):
    r=Q(r);nr=r.numerator;dr=r.denominator
    val=OMEGA_ZERO
    nr2=nr*nr;dr2=dr*dr
    for j in range(SERIES):
        u=4*j+1
        # b²/[u0(u0²+b²)] = 16*r²/[u*(u²+4r²)]
        num=16*nr2;den=u*(u*u*dr2+4*nr2)
        val=val+I(num*S//den,ceildiv(num*S,den))
    u=Q(4*SERIES+1,4)
    t=I.q(r*r/(4*u*u))
    inte=log1p_small(t)/I.q(2)
    extra=I.q(r*r/(4*u*(u*u+r*r/4)))
    return I(val.a+inte.a,val.b+inte.b+extra.b)


def amp2(r,k):
    r=Q(r)
    w=I.q(k)*PI/(I.q(2)*I.q(L))
    x=I.q(L)*I.q(r)-I.q(k)*PI/I.q(2)
    if x.absmax()<2:
        # A_k^2 = 4 L w_k^2 * sinc(L(r-wk))²/(r+wk)²
        return I.q(4*L)*w.sq()*sinc_near(x).sq()/(I.q(r)+w).sq()
    # A_k² = k²*pi²/L³ * [cos(Lr) or sin(Lr)]² / (r²-w²)²
    t=trig(I.q(L*r),'cos' if k%2 else 'sin')
    d=I.q(r*r)-w.sq()
    if d.a<=0<=d.b:raise ArithmeticError('polo aparente cruza zero sem regularizacao')
    return I.q(k*k)*PI.sq()*t.sq()/(I.q(L**3)*d.sq())


def eval_point(r,k):return amp2(r,k)*omega(r)/PI

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def read_fraction(d):
    den=int(d['denominator']);
    if den<=0:raise ValueError('denominador invalido')
    return Q(int(d['numerator']),den)

def inspect_report(path,k):
    d=json.loads(Path(path).read_text('utf8'))
    if k==1:
        if d.get('schema')!='NUMERIA.B3.G11.RATIONAL.1':raise ValueError('schema G11 incorreto')
        target=d['finite_midpoint_sum_enclosure']
    else:
        if d.get('schema')!='NUMERIA.B3.G12G22.RATIONAL.1':raise ValueError('schema G22 incorreto')
        target=d['G22_fixed_point_midpoint']
    mesh=[];cur=Q(0);count=0
    for band in d['mesh']:
        a=Q(band['from']);b=Q(band['to']);n=int(band['cells'])
        if a!=cur or b<=a or not 1<=n<=20000:raise ValueError('malha descontínua/invalida')
        mesh.append((a,b,n));cur=b;count+=n
    if cur!=160 or count!={1:9524,2:6230}[k]:raise ValueError('malha incompleta')
    lo,hi=map(read_fraction,target)
    if lo>hi:raise ValueError('intervalo B3 invertido')
    return mesh,(lo,hi)

def run_one(path,k,dump):
    mesh,ref=inspect_report(path,k)
    total=I.q(0);details=[];per=[];n_all=0
    for a,b,n in mesh:
        h=(b-a)/n
        band=I.q(0)
        for j in range(n):
            x=a+(2*j+1)*h/2
            y=eval_point(x,k)
            weighted=y*I.q(h)
            band+=weighted
            if dump:
                per.append({'r':str(x),'integrand':[str(Q(y.a,S)),str(Q(y.b,S))],
                            'weighted':[str(Q(weighted.a,S)),str(Q(weighted.b,S))]})
        total+=band;n_all+=n
        details.append({'from':str(a),'to':str(b),'cells':n,'sum_interval':band.pretty()})
        print(f'[B5] G{k}{k} faixa {a}-{b}: {n} avaliacoes intervalares',flush=True)
    low,high=Q(total.a,S),Q(total.b,S)
    incl=ref[0]<=low and high<=ref[1]
    inter=low<=ref[1] and ref[0]<=high
    nonvacuous=(high-low <= 2*(ref[1]-ref[0]))
    if not nonvacuous:
        print(f'[B5] ALERTA G{k}{k}: nova largura >2x largura B3')
    d={'component':f'G{k}{k}','source_input_sha256':sha(path),'points':n_all,'bands':details,
       'certified_finite_midpoint_sum':total.pretty(),'b3_midpoint_interval':list(map(str,ref)),
       'b5_enclosed_in_b3':incl,'b5_intersects_b3':inter,
       'b5_width_at_most_twice_b3':nonvacuous,
       'interval_width_decimal':str(float(high-low))}
    return d,per

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--g11',required=True,type=Path);ap.add_argument('--g22',required=True,type=Path)
    ap.add_argument('--out',type=Path,default=Path('RESULTADO_B5.json'))
    ap.add_argument('--dump-points',action='store_true',help='salva JSONL com envelope de cada ponto')
    args=ap.parse_args();start=time.monotonic()
    res=[];files=[]
    for path,k in ((args.g11,1),(args.g22,2)):
        ans,points=run_one(path,k,args.dump_points);res.append(ans)
        if args.dump_points:
            dest=args.out.with_name(f'PONTOS_G{k}{k}_B5.jsonl')
            dest.parent.mkdir(parents=True,exist_ok=True)
            with dest.open('w',encoding='utf8') as f:
                for p in points:f.write(json.dumps(p,ensure_ascii=False,sort_keys=True)+'\n')
            files.append({'file':dest.name,'sha256':sha(dest),'count':len(points)})
    valid=all(x['b5_intersects_b3'] and x['b5_width_at_most_twice_b3'] for x in res)
    report={'schema':'NUMERIA.B5.POINTWISE_RATIONAL_ENCLOSURE.1',
            'math_scope':'finite midpoint sums only, not full integrals',
            'method':'new directed fixed-point, near-pole sinc Taylor, trig Taylor, digamma convergent series+integral remainder',
            'points':sum(x['points'] for x in res),'fixed_point_scale':str(S),
            'interval_results':res,'point_files':files,'source_sha256':sha(Path(__file__).resolve()),
            'elapsed_seconds':round(time.monotonic()-start,3),
            'status':'SOMAS_COMPATIVEIS' if valid else 'DIVERGENCIA',
            'limits':['Prova computacional condicional aos lemas documentados',
              'Nao valida cotas globais de derivadas/erro de quadratura nem cauda alem de R=160',
              'Arquivos B3 nao armazenaram intervalos por ponto; compara somas e fornece novos intervalos',
              'Nao verifica formula explicita de Weil nem positividade global.']}
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    print('[B5] Resultado:',report['status'],'pontos',report['points'],'relatorio',args.out,flush=True)
    return 0 if valid else 2
if __name__=='__main__':raise SystemExit(main())
