#!/usr/bin/env python3
"""NUMERIA B3: enclosure independente G11, N=6, L=9/20, R=160.

SEM Arb, SEM mpmath: usa somente fracao exata, ponto-fixo dirigido,
series de Taylor com restos, derivadas majoradas e formula da digama
por serie com resto integral. Emite JSON de resultado.

Limite: calcula G_11 arquimediano, nao a matriz toda nem a formula
explicita de Weil. A prova das identidades usadas esta no relatorio.
"""
from __future__ import annotations
import argparse, hashlib, json, math, time
from fractions import Fraction as F
from pathlib import Path

L=F(9,20)
R=F(160)
A=F(1,4)
M=128
SCALE=10**45


def floor_div(a,b):
    if b<=0: raise ValueError('denominador <= 0')
    return a//b

def ceil_div(a,b):
    return -floor_div(-a,b)

class IV:
    __slots__=('lo','hi')
    def __init__(self,lo,hi=None):
        self.lo=int(lo);self.hi=int(self.lo if hi is None else hi)
        if self.lo>self.hi:raise ValueError('intervalo invertido')
    @classmethod
    def f(cls,f):
        f=F(f)
        return cls(floor_div(f.numerator*SCALE,f.denominator),ceil_div(f.numerator*SCALE,f.denominator))
    def __add__(self,other):
        other=as_iv(other);return IV(self.lo+other.lo,self.hi+other.hi)
    __radd__=__add__
    def __neg__(self):return IV(-self.hi,-self.lo)
    def __sub__(self,other):return self+-as_iv(other)
    def __rsub__(self,other):return as_iv(other)+-self
    def __mul__(self,other):
        other=as_iv(other)
        v=[self.lo*other.lo,self.lo*other.hi,self.hi*other.lo,self.hi*other.hi]
        return IV(floor_div(min(v),SCALE),ceil_div(max(v),SCALE))
    __rmul__=__mul__
    def recip(self):
        if self.lo<=0<=self.hi:raise ZeroDivisionError('divisor intervalar contem 0')
        # inversion with negative endpoints: for x<0 use -recip positive
        if self.hi<0:return (-self).recip().__neg__()
        return IV(floor_div(SCALE*SCALE,self.hi),ceil_div(SCALE*SCALE,self.lo))
    def __truediv__(self,other):return self*as_iv(other).recip()
    def __rtruediv__(self,other):return as_iv(other)*self.recip()
    def sq(self):
        if self.lo<=0<=self.hi:return IV(0,ceil_div(max(self.lo*self.lo,self.hi*self.hi),SCALE))
        x=min(self.lo*self.lo,self.hi*self.hi)
        y=max(self.lo*self.lo,self.hi*self.hi)
        return IV(floor_div(x,SCALE),ceil_div(y,SCALE))
    def abs_upper(self):return F(max(abs(self.lo),abs(self.hi)),SCALE)
    def as_fraction(self):return F(self.lo,SCALE),F(self.hi,SCALE)

def as_iv(x):return x if isinstance(x,IV) else IV.f(x)


def atan_interval(q,n):
    q=F(q); s=F(0)
    for k in range(n):s+=(-1)**k*q**(2*k+1)/F(2*k+1)
    nxt=q**(2*n+1)/F(2*n+1)
    return (s,s+nxt) if n%2==0 else (s-nxt,s)


def pi_bounds():
    # 16 atan(1/5) - 4 atan(1/239)
    x=atan_interval(F(1,5),80)
    y=atan_interval(F(1,239),40)
    return 16*x[0]-4*y[1],16*x[1]-4*y[0]


def log2_bounds():
    q=F(1,3); n=95
    s=2*sum((q**(2*k+1)/F(2*k+1) for k in range(n)),F(0))
    t=2*q**(2*n+1)/F((2*n+1)) /(1-q*q)
    return s,s+t

PI_LO,PI_HI=pi_bounds()
LN2_LO,LN2_HI=log2_bounds()


def log_fraction(x,n=45):
    """Enclosure de log(x) para x racional positivo por artanh geometrico."""
    x=F(x)
    if x<=0:raise ValueError('log nao-positivo')
    k=0
    while x>=2: x/=2;k+=1
    while x<1: x*=2;k-=1
    q=(x-1)/(x+1)
    s=F(0)
    for j in range(n):s+=2*q**(2*j+1)/F(2*j+1)
    rem=2*q**(2*n+1)/F(2*n+1)/(1-q*q)
    if k>=0: return s+k*LN2_LO,s+rem+k*LN2_HI
    return s+k*LN2_HI,s+rem+k*LN2_LO


def gamma_bounds():
    n=64
    harm=sum((F(1,i) for i in range(1,n+1)),F(0))
    Bs=[F(1,6),-F(1,30),F(1,42),-F(1,30),F(5,66),-F(691,2730),F(7,6),-F(3617,510)]
    terms=[Bs[j]/F(2*(j+1)*n**(2*(j+1))) for j in range(len(Bs))]
    base=harm-F(1,2*n)
    # EM alternating corrections; k=7 ends positive, k=8 negative.
    s7=base+sum(terms[:7]);s8=s7+terms[7]
    return s8-6*LN2_HI,s7-6*LN2_LO

GAM_LO,GAM_HI=gamma_bounds()
LNPI_LO,LNPI_HI=log_fraction((PI_LO+PI_HI)/2,n=130)
# enclosure log(pi) monotone: midpoint log + |pi - midpoint| / pi_low
extra=(PI_HI-PI_LO)/(2*PI_LO)
LNPI_LO-=extra;LNPI_HI+=extra
OMEGA0=IV.f(-GAM_HI-PI_HI/2-3*LN2_HI-LNPI_HI)+IV(0,0)
OMEGA0=IV(OMEGA0.lo,IV.f(-GAM_LO-PI_LO/2-3*LN2_LO-LNPI_LO).hi)
PI=IV(IV.f(PI_LO).lo,IV.f(PI_HI).hi)


def sqrt_bounds(q,dp=40):
    q=F(q); t=10**dp
    v=math.isqrt(q.numerator*t*t//q.denominator)
    return F(v,t),F(v+1,t)

SQRTL_LO,SQRTL_HI=sqrt_bounds(L)


def cos_bound_for_r(r,order=40):
    """Enclosure cos(L*r) por Taylor com aritmetica de ponto fixo dirigida.

    Reducao de argumento x=L*r-2*k*pi, com k INTEIRO qualquer e |x|<4.
    A prova do resto usa |cos^(n)(x)|<=1 para todo real x.
    """
    x=L*F(r)
    k=int(round(float(x)/(2*math.pi)))
    t=IV.f(x)-IV.f(2*k)*PI
    if t.abs_upper()>=4:raise ArithmeticError('reducao angular invalida')
    t2=t.sq()
    term=IV.f(1)
    val=term
    for j in range(1,order+1):
        term=term*(-t2)/IV.f((2*j-1)*(2*j))
        val+=term
    eps=F(4)**(2*order+2)/F(math.factorial(2*order+2))
    rem=IV.f(eps)
    return IV(val.lo-rem.hi,val.hi+rem.hi)


def omega_at_r(r):
    """Serie de digama com cauda cercada por integral e primeira parcela."""
    r=F(r);b2=r*r/4
    val=OMEGA0
    for j in range(M):
        u=F(j)+A
        val += IV.f(b2/(u*(u*u+b2)))
    u=F(M)+A
    integral=(F(1)+b2/(u*u))
    low,high=log_fraction(integral,30)
    tail_lo=low/2
    tail_hi=high/2+b2/(u*(u*u+b2))
    val+=IV(IV.f(tail_lo).lo,IV.f(tail_hi).hi)
    return val


def a1_square_at_r(r):
    r=F(r)
    D=IV.f(r*r)-PI.sq()/IV.f(4*L*L)
    # A_1^2 = (pi^2/L^3)*cos(L*r)^2/(r^2 - w^2)^2.
    if D.lo<=0<=D.hi:raise ArithmeticError('intervalo para polo removivel; aumente a precisao')
    return PI.sq()*cos_bound_for_r(r).sq()/(IV.f(L**3)*D.sq())


def integrand_at_r(r):
    return a1_square_at_r(r)*omega_at_r(r)/PI


def upper_omega_derivs(left,right):
    """Omega'(r)>=0, majorantes de |Omega'|, |Omega''| na banda."""
    l=F(left);h=F(right)
    d1=F(0);d2=F(0)
    for j in range(M):
        u=F(j)+A; u2=u*u
        first=min(u*h/(2*(u2+l*l/4)**2),F(1,3*u2))
        second=min(u*max(abs(u2-3*l*l/4),abs(u2-3*h*h/4))/(2*(u2+l*l/4)**3),F(1,2*u**3))
        d1+=first;d2+=second
    u=F(M)+A
    d1+=(F(1,u*u)+F(1,u))/3
    d2+=F(1,2*u**3)+F(1,4*u*u)
    return d1,d2


def band_m2(left,right):
    l=F(left);h=F(right)
    omega_abs=max(omega_at_r(l).abs_upper(),omega_at_r(h).abs_upper())
    od1,od2=upper_omega_derivs(l,h)
    if h<=6:
        a0=2*SQRTL_HI
        a1=SQRTL_HI*L
        a2=F(2,3)*SQRTL_HI*L**2
    else:
        if l<6:raise ValueError('faixa fora da regiao valida')
        w2=PI_HI**2/(4*L*L)
        D=l*l-w2
        if D<=0:raise AssertionError('banda r>=6 deve estar longe do polo')
        C=PI_HI/(L*SQRTL_LO)
        a0=C/D
        a1=C*(L/D+2*h/D**2)
        a2=C*(L*L/D+4*L*h/D**2+2/D**2+8*h*h/D**3)
    f2=((2*a1*a1+2*a0*a2)*omega_abs+4*a0*a1*od1+a0*a0*od2)/PI_LO
    return f2,{'omega_abs_upper':omega_abs,'omega_prime_abs_upper':od1,
               'omega_double_prime_abs_upper':od2,'A0_abs_upper':a0,
               'A1_abs_upper':a1,'A2_abs_upper':a2}


def build_mesh(bands,target):
    """Escolhe n por cota de erro via sqrt estimativa; verifica rigorosamente c/n² <= quota."""
    budgets=[]
    for (a,b) in bands:
        m2,diag=band_m2(a,b)
        c=m2*(F(b)-F(a))**3/24
        budgets.append((c,diag,m2))
    weights=[float(c)**(1/3) for c,_,_ in budgets]
    total=sum(weights)
    out=[]
    for ((a,b),(c,diag,m2),weight) in zip(bands,budgets,weights):
        E=target*F.from_float(weight/total)
        n=max(1,math.ceil(math.sqrt(float(c/E))))
        while c/(n*n)>E:n+=1
        error=c/(n*n)
        out.append({'a':F(a),'b':F(b),'n':n,'error':error,'m2':m2,'diagnostics':diag})
    return out


def logR_bounds():return log_fraction(R,65)


def tail_bound():
    """Cauda integrando |Omega(r)| <= 6 + log(r) para r >=160.

    |A1(r)| <= (pi/L^(3/2))/(r²-w²), w=pi/(2L).
    """
    loglo,loghi=logR_bounds()
    K=1-PI_HI**2/(4*L*L*R*R)
    if K<=0:raise ArithmeticError('denominador da cota de cauda invalido')
    return PI_HI*(6+loghi+F(1,3))/(3*L**3*R**3*K**2)


def jsonf(x):
    x=F(x)
    return {'numerator':str(x.numerator),'denominator':str(x.denominator),'decimal_approx':format(float(x),'.15g')}


def json_upper(x):
    # Limita o tamanho do registro sem perder rigor: sempre arredonda PARA CIMA.
    return jsonf(F(IV.f(x).hi,SCALE))


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def run(reference,output,goal,verbose):
    if not (OMEGA0.lo<0 and OMEGA0.hi<0 and OMEGA0.lo>IV.f(-6).hi):
        raise ArithmeticError('falha na cota inicial de Omega')
    if not (PI_LO>3 and PI_HI<4):
        raise ArithmeticError('falha nos limites de pi')
    if goal<=0:raise ValueError('error budget deve ser positivo')
    tstart=time.monotonic()
    bands=[(F(0),F(6)),(F(6),F(12)),(F(12),F(24)),(F(24),F(48)),(F(48),F(96)),(F(96),R)]
    mesh=build_mesh(bands,F(goal))
    print('[NUMERIA B3] Malha certificada: '+ ', '.join(f'{band["a"]}-{band["b"]}: {band["n"]} celulas' for band in mesh),flush=True)
    sum_iv=IV.f(0);sum_error=F(0)
    for band in mesh:
        a,b,n=band['a'],band['b'],band['n'];h=(b-a)/n
        part=IV.f(0)
        for idx in range(n):
            mid=a+(2*idx+1)*h/2
            part+=integrand_at_r(mid)*IV.f(h)
        sum_iv+=part
        sum_error+=band['error']
        if verbose:
            print(f'[B3] [{float(a):g},{float(b):g}] {n} celulas; erro cert. <= {float(band["error"]):.5g}',flush=True)
    # E2: upper bound global inclui a soma dos limites individuais JA arredondados.
    # max por seguranca: cada cota e majorante e evita subestimar o total.
    rounded_band_error_sum=sum((F(IV.f(band['error']).hi,SCALE) for band in mesh),F(0))
    sum_error_export=max(sum_error,rounded_band_error_sum)
    # Restricao do erro de quadratura para a integral exata em [0,R].
    e=IV.f(sum_error_export)
    finite=IV(sum_iv.lo-e.hi,sum_iv.hi+e.hi)
    tail=IV.f(tail_bound())
    result=IV(finite.lo-tail.hi,finite.hi+tail.hi)
    refl=json.loads(reference.read_text(encoding='utf-8'))
    p=refl['parameters']
    if not (int(p['N'])==6 and F(p['L'])==L and F(p['R'])==R):
        raise ValueError('referencia nao corresponde ao caso L=.45,N=6,R=160')
    ent=refl['archimedean_entry_enclosures'][0][0]
    ref_lo=F(ent['lower']);ref_hi=F(ent['upper'])
    out_lo,out_hi=result.as_fraction()
    inside=ref_lo<=out_lo and out_hi<=ref_hi
    overlap=ref_lo<=out_hi and out_lo<=ref_hi
    report={
      'schema':'NUMERIA.B3.G11.RATIONAL.1','method':'midpoint_rational_fixed_point+explicit_second_derivative_bound+independent_tail',
      'scope':'ONLY archimedean G11, L=9/20,N=6,R=160',
      'reference_sha256':sha(reference),'reference_filename':reference.name,
      'auditor_source_sha256':sha(Path(__file__).resolve()),
      'pure_python_standard_library':True,
      'M_digamma_series':M,'fixed_point_scale':str(SCALE),
      'omega0_enclosure':[jsonf(x) for x in OMEGA0.as_fraction()],
      'finite_midpoint_sum_enclosure':[jsonf(x) for x in sum_iv.as_fraction()],
      'quadrature_absolute_error_upper':json_upper(sum_error_export),
      'tail_absolute_error_upper':json_upper(tail_bound()),
      'g11_independent_enclosure':[jsonf(out_lo),jsonf(out_hi)],
      'g11_historical_enclosure':[jsonf(ref_lo),jsonf(ref_hi)],
      'independent_inside_historical':inside,
      'intersects_historical':overlap,
      'mesh':[{'from':str(x['a']),'to':str(x['b']),'cells':x['n'],
               'f2_absolute_bound':json_upper(x['m2']),
               'midpoint_error_bound':json_upper(x['error'])} for x in mesh],
      'elapsed_seconds':round(time.monotonic()-tstart,3),
      'limitations':['Only G11, not whole G/A matrix.','Uses Euler-Maclaurin bound and Fourier formula as mathematical premises.',
                     'No claim about full Weil explicit formula or global positivity.']
    }
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print('[NUMERIA B3] Erro quadratura <= %.9g; cota cauda <= %.9g'%(float(sum_error_export),float(tail_bound())),flush=True)
    print('[NUMERIA B3] G11 pertence a [%.15g, %.15g]'%(float(out_lo),float(out_hi)),flush=True)
    print('[NUMERIA B3] Referencia    [%.15g, %.15g]'%(float(ref_lo),float(ref_hi)),flush=True)
    print('[NUMERIA B3] Contido no certificado historico:',inside,flush=True)
    print('[NUMERIA B3] Relatorio:',output,flush=True)
    return 0 if inside else 2


def main():
    pa=argparse.ArgumentParser(description=__doc__)
    pa.add_argument('--reference',type=Path,required=True)
    pa.add_argument('--output',type=Path,default=Path('RESULTADO_B3_G11.json'))
    pa.add_argument('--error-budget',default='0.00001',help='erro de ponto medio permitido; padrao 1e-5')
    pa.add_argument('--verbose',action='store_true')
    args=pa.parse_args()
    return run(args.reference,args.output,F(args.error_budget),args.verbose)

if __name__=='__main__':raise SystemExit(main())
