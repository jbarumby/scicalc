#!/usr/bin/env python3
"""Fase 4 NUMERIA: nós gerais, índices (i,j), somente Fraction; nunca importa flint.

Protótipo auditável para uma pequena lista de nós da malha real da Fase 3.
Não é ainda uma integral rigorosa nem certifica B^T W B.
"""
from __future__ import annotations
import argparse
from functools import lru_cache
from decimal import Decimal
from fractions import Fraction as Q
from pathlib import Path
import json
from math import factorial
from fase4_nos_sem_arb import (
    I, add, sub, scal, mul, neg, sq, div_positive, pi_interval,
    ln_interval, psi_quarter_interval, sqrt_rational_interval,
    sinc_rational_point, summary, float_str,
)


def nearest_integer(q: Q) -> int:
    """Arredondamento simétrico ao inteiro mais próximo, sem float."""
    q = Q(q)
    if q >= 0:
        return (2*q.numerator + q.denominator)//(2*q.denominator)
    return -nearest_integer(-q)


@lru_cache(maxsize=2048)
def sinc_reduzido(x: I, m: int = 38) -> I:
    """sinc(x) para x real, inclusive |x| grande: redução de sin por 2*pi.
    Para |x|<=1 usa Taylor diretamente; nos demais divide seno pelo intervalo x.
    """
    mid = (x[0] + x[1])/2
    if max(abs(x[0]), abs(x[1])) <= 1:
        s = sinc_rational_point(mid, 30)
        rad = (x[1]-x[0])/2
        # |sinc'| <= 1/2 por sinc(x)=int_0^1 cos(tx)dt.
        return s[0]-rad/2, s[1]+rad/2
    if x[0] <= 0 <= x[1]:
        raise ValueError('intervalo cruzando zero fora do ramo Taylor')
    pi = pi_interval()
    two_pi = scal(pi, Q(2))
    n = nearest_integer(mid / ((two_pi[0]+two_pi[1])/2))
    residual = sub(x,scal(two_pi,Q(n)))
    y = (residual[0]+residual[1])/2
    rad = (residual[1]-residual[0])/2
    # Taylor do seno truncado (m termos) e resto de Maclaurin: |y|^(2m+1)/(2m+1)!
    s = sum((Q((-1)**k)*y**(2*k+1)/factorial(2*k+1) for k in range(m)),Q(0))
    remainder = abs(y)**(2*m+1)/factorial(2*m+1)
    sine = (s-remainder-rad,s+remainder+rad)  # |sin'|<=1
    if max(abs(residual[0]), abs(residual[1])) > 4:
        raise ArithmeticError('falhou a redução módulo 2pi')
    return div_signed(sine,x)


def div_signed(a:I, b:I)->I:
    if b[0]>0: return div_positive(a,b)
    if b[1]<0: return neg(div_positive(a,neg(b)))
    raise ValueError('denominador passa por zero')


def ln_fixed_interval(x:Q, n:int=80, digits:int=42)->I:
    """Log racional dirigido por série atanh com soma fixa, sem GCD enorme."""
    if x<=0: raise ValueError('log requer x>0')
    t=(x-1)/(x+1)
    negative=t<0
    t=abs(t)
    scale=10**digits
    power=t
    total=0
    for k in range(n):
        v=2*power/Q(2*k+1)
        total += (v.numerator*scale)//v.denominator
        power *= t*t
    # resto da cauda, com arredondamento da soma <= n/scale
    rem=2*power/(Q(2*n+1)*(1-t*t))
    positive=(Q(total,scale),Q(total+n,scale)+rem)
    return neg(positive) if negative else positive


@lru_cache(maxsize=1)
def ln_pi_fast()->I:
    p=pi_interval()
    return ln_fixed_interval(p[0],100), ln_fixed_interval(p[1],100)


def tail_accelerated(r:Q, N:int=64) -> I:
    """Soma_n>=0 b²/(u_n(u_n²+b²)), u_n=n+1/4, b=r/2.

    Após N termos usa Euler-Maclaurin com termo B2 e resto limitado pelo B4,
    decorrência da fração parcial de coth(t/2):
    1/t+1/2+t/12-t³/720 <= 1/(1-e^-t) <= 1/t+1/2+t/12.
    Todas as expressões são racionais, exceto log racional com Taylor limitado.
    """
    r=Q(r); b2=(r/2)**2
    if b2==0: return Q(0), Q(0)
    if N < 2: raise ValueError('N minimo 2')
    u = Q(N)+Q(1,4)
    # Cada parcela aproximada a 35 dígitos por divisão inteira dirigida.
    # Mantém o custo das operações e o tamanho dos denominadores controlados.
    scale=10**35
    total_lo=0; total_hi=0
    for n in range(N):
        t=Q(n)+Q(1,4)
        term=b2/(t*(t*t+b2))
        x=(term.numerator*scale)//term.denominator
        total_lo+=x
        total_hi+=x+1
    sums=(Q(total_lo,scale),Q(total_hi,scale))
    Ilog=scal(ln_fixed_interval(1+b2/u**2,55),Q(1,2))
    g=b2/(u*(u*u+b2))
    B2=b2*(3*u*u+b2)/(12*u*u*(u*u+b2)**2)
    # Integral t³ e^{-ut}(1-cos(bt)) /720, explicitamente positiva.
    B4=(Q(1,u**4)-(u**4-6*u*u*b2+b2*b2)/(u*u+b2)**4)/120
    if not (B4>=0 and B2>=0): raise AssertionError('resto Bernoulli com sinal errado')
    low=Ilog[0]+g/2+B2-B4
    high=Ilog[1]+g/2+B2
    return add(sums,(low,high))


@lru_cache(maxsize=512)
def omega_fast(r:Q,N:int=64)->I:
    pi=pi_interval()
    lnpi=(ln_pi_fast()[0][0],ln_pi_fast()[1][1])
    return sub(add(psi_quarter_interval(),tail_accelerated(r,N)),lnpi)


@lru_cache(maxsize=2048)
def amp_fast(r:Q,k:int,L:Q=Q(9,20))->I:
    if k<1:raise ValueError('indice k>=1')
    w = div_positive(scal(pi_interval(),Q(k)),(2*L,2*L))
    rr=(r,r)
    u_minus=scal(sub(rr,w),L)
    u_plus=scal(add(rr,w),L)
    s1=sinc_reduzido(u_minus)
    s2=sinc_reduzido(u_plus)
    combo=add(s1,s2) if k%2 else sub(s1,s2)
    return mul(sqrt_rational_interval(L),combo)


def qij_fast(r:Q,i:int,j:int,N:int=64,L:Q=Q(9,20))->I:
    if (i-j)%2: return Q(0),Q(0)
    phase = -1 if (abs(i-j)//2)%2 else 1
    t=mul(mul(amp_fast(r,i,L),amp_fast(r,j,L)),omega_fast(r,N))
    return scal(div_positive(t,pi_interval()),Q(phase))


def run(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--nos',default='0;1;4;10;40;80;160')
    p.add_argument('--pares',default='1,1;1,3;2,2;9,9;10,10')
    p.add_argument('--series',type=int,default=64)
    p.add_argument('--out',default='FASE4_LOTE_NOS.json')
    args=p.parse_args(argv)
    rs=[Q(Decimal(v.strip())) for v in args.nos.split(';')]
    pairs=[tuple(map(int,part.split(','))) for part in args.pares.split(';')]
    if not rs or len(rs)>1000: p.error('1 a 1000 nos para o prototipo')
    if not all(0<=r<=160 for r in rs):p.error('exige 0<=r<=160')
    if not all(1<=i<=10 and 1<=j<=10 for i,j in pairs):p.error('indices 1..10')
    results=[]
    for r in rs:
        omega=omega_fast(r,args.series)
        vals={f'{i},{j}':summary(qij_fast(r,i,j,args.series)) for i,j in pairs}
        print(f'r={r}: omega largura={float_str(omega[1]-omega[0],5)}, {len(vals)} pares',flush=True)
        results.append({'r':str(r),'omega':summary(omega),'q_ij':vals})
    data={'status':'nodal_enclosures_only_not_full_integral','method':'Fraction without Arb',
          'series_terms':args.series,'nodes':results,'pairs':[list(x) for x in pairs]}
    Path(args.out).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(f'ARQUIVO: {args.out}')
    return 0

if __name__=='__main__':raise SystemExit(run())
