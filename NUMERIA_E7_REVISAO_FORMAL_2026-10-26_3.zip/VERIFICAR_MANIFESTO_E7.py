#!/usr/bin/env python3
"""Confere arquivos imutáveis do pacote E7 pelo SHA-256 (Python padrão)."""
from pathlib import Path
import json,hashlib

def main():
    root=Path(__file__).resolve().parent
    m=json.loads((root/'MANIFESTO_SHA256.json').read_text(encoding='utf8'))
    files=m['sha256']
    for name,expected in files.items():
        p=root/name
        if not p.is_file():raise RuntimeError('arquivo ausente: '+name)
        if hashlib.sha256(p.read_bytes()).hexdigest()!=expected:
            raise RuntimeError('HASH INCORRETO: '+name)
    print(f'[E7 SHA256] {len(files)}/{len(files)} arquivos conferidos; manifest integro')
if __name__=='__main__':main()
