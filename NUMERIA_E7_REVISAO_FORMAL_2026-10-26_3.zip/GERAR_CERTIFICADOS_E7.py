#!/usr/bin/env python3
"""Compõe somas B5 + erro B3 corrigido + Proposição 6 e revisa cada JSONL.
Todas as operações de conferência são racionais exatas. Não avalia digamma.
"""
from __future__ import annotations
import argparse,hashlib,json
from fractions import Fraction as Q
from pathlib import Path
from REVISOR_E7 import frac,sha,tail_prop6,inspect_b3,inspect_prop6
S=10**42

def ceiling(a,b):return -((-a)//b)
def fixed(q):
    q=Q(q)
    return q.numerator*S//q.denominator,ceiling(q.numerator*S,q.denominator)

def directed_product(y,h):
    ylo,yhi=y
    hlo,hhi=fixed(h)
    vals=[ylo*hlo,ylo*hhi,yhi*hlo,yhi*hhi]
    return min(vals)//S,ceiling(max(vals),S)

def one(root,k,b5row,file_meta):
    bn='RESULTADO_B3_G11_E2_CORRIGIDO.json' if k==1 else 'RESULTADO_B3_G22_E2_CORRIGIDO.json'
    b3=json.loads((root/'corrigidos'/bn).read_text('utf8'))
    pts=root/'b5'/f'PONTOS_G{k}{k}_B5.jsonl'
    if file_meta['file'] != pts.name or sha(pts)!=file_meta['sha256']:
        raise AssertionError('hash dos pontos incompatível com B5')
    totlo=tothi=0;count=0
    with pts.open(encoding='utf8') as stream:
        for band in b3['mesh']:
            a=Q(band['from']);b=Q(band['to']);n=int(band['cells']);h=(b-a)/n
            for j in range(n):
                p=json.loads(next(stream))
                mid=a+(2*j+1)*h/2
                if Q(p['r'])!=mid:raise AssertionError('coordenada média não corresponde à malha')
                il,ih=map(Q,p['integrand']);wl,wh=map(Q,p['weighted'])
                if il>ih or wl>wh:raise AssertionError('intervalo inválido')
                # Os intervalos já estão serializados em múltiplos de 10^-42.
                if any(x.denominator>1 and (x*S).denominator!=1 for x in (il,ih,wl,wh)):
                    raise AssertionError('escala fixa incompatível')
                elo,ehi=directed_product((int(il*S),int(ih*S)),h)
                if wl!=Q(elo,S) or wh!=Q(ehi,S):
                    raise AssertionError('peso não corresponde ao integrando e h dirigido')
                totlo+=int(wl*S);tothi+=int(wh*S);count+=1
        if stream.readline():raise AssertionError('registros adicionais inesperados')
    if count!=file_meta['count'] or count!=b5row['points']:
        raise AssertionError('quantidade de registros divergente')
    sumlo,sumhi=map(Q,b5row['certified_finite_midpoint_sum'])
    if sumlo>Q(totlo,S) or sumhi<Q(tothi,S):
        raise AssertionError('soma dos pontos não é coberta pelo relatório B5')
    # Conferir novamente os erros e limites antes de combinar resultados.
    inspect_b3(root/'corrigidos'/bn,k)
    error=frac(b3['quadrature_absolute_error_upper'] if k==1 else b3['G22_quadrature_error_upper'])
    tail=tail_prop6(k,k)
    lower,upper=sumlo-error-tail,sumhi+error+tail
    checks=[]
    for path in sorted((root/'referencias_nove').glob('*.json')):
        data=json.loads(path.read_text('utf8'))
        g=data['archimedean_entry_enclosures'][k-1][k-1]
        covered=Q(g['lower'])<=lower<=upper<=Q(g['upper'])
        checks.append({'file':path.name,'contained':covered})
    if len(checks)!=9 or not all(c['contained'] for c in checks):
        raise AssertionError('nova faixa não contida em todas as nove referências')
    return {'entry':f'G{k}{k}','point_records':count,'sum_b5':[str(sumlo),str(sumhi)],
            'quadrature_error_b3':str(error),'tail_proposition6':str(tail),
            'combined_interval':[str(lower),str(upper)],
            'decimal_display':[f'{float(lower):.16f}',f'{float(upper):.16f}'],
            'reference_checks':checks,'point_sha256':sha(pts)}

def run(root):
    root=Path(root)
    b5file=root/'b5'/'RESULTADO_B5.json'
    obj=json.loads(b5file.read_text('utf8'))
    if obj['schema']!='NUMERIA.B5.POINTWISE_RATIONAL_ENCLOSURE.1':raise AssertionError('schema incorreto')
    if sha(root/'fontes'/'AUDITOR_PONTOS_B5.py')!=obj['source_sha256']:
        raise AssertionError('hash do avaliador original B5 divergente')
    if len(obj['interval_results'])!=2 or len(obj['point_files'])!=2:raise AssertionError('faltam entradas')
    result=[one(root,k,next(r for r in obj['interval_results'] if r['component']==f'G{k}{k}'),
                 next(r for r in obj['point_files'] if r['file']==f'PONTOS_G{k}{k}_B5.jsonl')) for k in (1,2)]
    if sum(r['point_records'] for r in result)!=15754:raise AssertionError('total não é 15754')
    return {'status':'INTERVALOS_COMPOSTOS_SOB_LEMAS_DOCUMENTADOS','results':result,
            'limitations':['A verificação independente dos registros não prova que cada valor do integrando esteja encerrado corretamente.',
                           'O erro de quadratura utiliza as cotas de segunda derivada formalizadas no parecer E7.',
                           'A fórmula explícita global e a correção do centro dos certificados Arb não são provadas.']}

def main():
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    a.add_argument('--out',type=Path)
    args=a.parse_args()
    obj=run(args.root)
    if args.out:
        args.out.parent.mkdir(parents=True,exist_ok=True)
        args.out.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n','utf8')
    for r in obj['results']:
        print(f'[E7] {r["entry"]}: {r["point_records"]} pontos e 9/9 referencias; I=[{r["decimal_display"][0]}, {r["decimal_display"][1]}]')
    print('[E7] total 15754 registros, somas dirigidas, erros B3 e caudas Prop6 combinados')

if __name__=='__main__':main()
