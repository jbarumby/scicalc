# NUMERIA–RIEMANN — E7: revisão matemática das cotas e composição de integrais

**Data:** 26 de outubro de 2026. **Versão:** E7-1. **Escopo:** `L=9/20`, `R=160`, entradas arquimedianas `G11`, `G12`, `G22`, prova da Proposição 6, e auditoria do majorante complexo da Fase 3/4.

## Conclusão resumida

- **Conferidas as deduções matemáticas centrais** de Euler–Maclaurin para a constante γ e para a série da digama, a majoração da segunda derivada no método dos pontos médios e a Proposição 6 para a cauda, usando identidades clássicas com referências identificadas.
- **16/16 condições aritméticas e geométricas conferidas** pelo `REVISOR_E7.py`, inclusive o erro de Cauchy da Fase 3/4, que foi reobtido exatamente como `4154891126177792/209922127267236328125`.
- **G11 e G22:** cotas de 11 faixas, malhas de 9.524 e 6.230 pontos e erros finais aprovados após a correção E2.
- **Proposição 6:** todos os 100 raios de mesma paridade dos três certificados `lemma5` conferidos; o teste de raio **não verifica** a posição do centro de cada integral.
- **Nova composição E7:** os **15.754 registros individuais B5** tiveram hashes, coordenadas, pesos de ponto fixo e somatórios auditados; os intervalos resultantes, após erro da quadratura e cauda Prop. 6, estão contidos nas nove referências.
- **Status correto:** `APROVADO_SOB_IDENTIDADES_MATEMATICAS_EXPLICITADAS` e `INTERVALOS_COMPOSTOS_SOB_LEMAS_DOCUMENTADOS`. Não é revisão por árbitro externo, demonstração formal de programas, nem demonstração da Hipótese de Riemann.

## 1. O que está sendo calculado

Sejam `L>0`, `w_k=kπ/(2L)`, `f_k(t)=sin(w_k(t+L))/√L` para `-L≤t≤L` e zero fora. Sua transformada é

\[
 F_k(r)=i e^{-ik\pi/2}A_k(r), \quad A_k(r)=\frac{2\sqrt L\,w_k}{r+w_k}\,\mathrm{sinc}(L(r-w_k)).
\]

Para `r` real e `i-j` ímpar, `Re(F_i\overline{F_j})=0` exatamente. Isto prova `G12=0` sem cálculo de quadratura.

O peso é `Ω(r)=Re ψ(1/4+ir/2)−log π`; a integral estudada é

\[
 G_{ij}=\frac{1}{\pi}\int_0^\infty\operatorname{Re}(F_i(r)\overline{F_j(r)})\,\Omega(r)\,dr.
\]

**Hipótese de interpretação:** esta integral é o termo *arquimediano* pretendido. Sua presença e normalização na fórmula explícita global de Weil dependem de uma prova separada de admissibilidade das funções de teste e de todas as normalizações.

## 2. Digama: série real, convergência e derivadas

Para `u_j=j+1/4`, `b=r/2`, a identidade da digama (DLMF 5.7.6) dá

\[
 \Omega(r)=\Omega(0)+\sum_{j\ge0}\frac{b^2}{u_j(u_j^2+b^2)},\qquad
 \Omega(0)=-\gamma-\frac\pi2-3\log2-\log\pi.
\]

Defina `q_j(r)=r²/[4u_j(u_j²+r²/4)]`. Em `r≥0`,

\[
 q'_j(r)=\frac{u_j r}{2(u_j^2+r^2/4)^2}\ge0,\quad
 q''_j(r)=\frac{u_j(u_j^2-3r^2/4)}{2(u_j^2+r^2/4)^3}.
\]

Em qualquer intervalo compacto de `r≥0`, as séries de `q_j` e de suas duas derivadas convergem uniformemente (`O(j⁻³)`, `O(j⁻³)` e `O(j⁻³)` com constantes dependentes do compacto). Justifica-se a diferenciação termo a termo e a monotonicidade de `Ω`.

Com `t=r²/(4u_j²)≥0`,

\[
 |q''_j(r)|=\frac{|1-3t|}{2u_j^3(1+t)^3}\le\frac1{2u_j^3}.
\]

Para `t≤1/3`, `(1+t)^3-(1-3t)=6t+3t²+t³≥0`. Para `t≥1/3`, `(1+t)^3-(3t-1)=2+3t²+t³≥0`. Para a primeira derivada, a maximização exata fornece `max_r q'_j=9/(16√3 u_j²)<1/(3u_j²)`; a última desigualdade equivale a `729<768`.

As estimativas de cauda para as derivadas seguem de comparação soma–integral: `∑_{j≥M}1/u_j²≤1/u_M²+1/u_M` e `∑_{j≥M}1/(2u_j³)≤1/(2u_M³)+1/(4u_M²)`.

Para a própria série, `q(u)=b²/[u(u²+b²)]` é positiva e decrescente. Assim

\[
 \frac12\log(1+b²/u_M²)\le\sum_{j≥M}q(u_j)\le
 \frac12\log(1+b²/u_M²)+q(u_M).
\]

Esta desigualdade fundamenta o avaliador B3/B5 de `Ω` sem usar a digama complexa como oráculo.

## 3. Constante de Euler–Mascheroni: sinal do resto

A expansão da digama para **argumento real positivo**, com resto do sinal do primeiro termo omitido (NIST DLMF §5.11(ii)), resulta em

\[
 \gamma=H_n-\log n-\frac{1}{2n}+\sum_{k≥1}\frac{B_{2k}}{2k n^{2k}}.
\]

Entre as truncações em `k=7` e `k=8` está o valor real `γ`. O termo `B16/(16n^16)` é negativo, portanto a truncação `k=8` é o limite inferior. É válido aqui porque `n=64>0` (e não se está aplicando o mesmo sinal automaticamente à digama em argumentos complexos). `REVISOR_E7.py` calcula `γ`, `π`, `ln 2`, `ln π`, `Ω(0)` com frações racionais, enclosures de séries alternantes e resto geométrico.

**Restrição essencial:** uma expansão assintótica sem teorema do resto **não** bastaria. A versão DLMF para eixo positivo é a utilizada.

## 4. Euler–Maclaurin acelerada da Fase 4: prova explícita da cota B2/B4

Para `u>0` e `b≥0`,

\[
 g(u)=\frac{b²}{u(u²+b²)}=\int_0^\infty e^{-ut}(1-\cos(bt))\,dt.
\]

Por Tonelli, a cauda da série é

\[
 \sum_{n≥0}g(u+n)=\int_0^\infty \frac{e^{-ut}(1-\cos(bt))}{1-e^{-t}}\,dt.
\]

A expansão em frações parciais (NIST DLMF 4.36.3), aplicada a `coth(t/2)`, dá para todo `t>0`:

\[
 \frac{1}{1-e^{-t}}=\frac1t+\frac12+2t\sum_{n≥1}\frac{1}{t²+4\pi²n²}.
\]

Usando `1/(a+x)≤1/a` e `1/(a+x)≥1/a-x/a²` para `a>0,x≥0`, juntamente com `∑n⁻²=π²/6` e `∑n⁻⁴=π⁴/90`, obtemos **globalmente**

\[
 \frac1t+\frac12+\frac{t}{12}-\frac{t³}{720}
 \le\frac{1}{1-e^{-t}}
 \le\frac1t+\frac12+\frac{t}{12}.
\]

Multiplique por `e^{-ut}(1−cos(bt))≥0` e integre. Escrevendo `I=∫_u^∞g(v)dv=(1/2)ln(1+b²/u²)` e `g=g(u)`,

\[
 I+\frac{g}{2}+B_2-B_4\le\sum_{n≥0}g(u+n)
 \le I+\frac g2+B_2,
\]

onde

\[
 B_2=-\frac{g'(u)}{12}=\frac{b²(3u²+b²)}{12u²(u²+b²)^2},
\]

\[
 B_4=\frac1{120}\left[\frac1{u^4}-\frac{u^4-6u²b²+b^4}{(u²+b²)^4}\right]≥0.
\]

A última positividade decorre diretamente da representação integral ou, pondo `x=b²/u²≥0`, da identidade `(1+x)^4−(1−6x+x²)=10x+5x²+4x³+x⁴≥0`. `VERIFICAR_EM_FASE4_E7.py` compara essas expressões por frações exatas em 15 casos: **15/15 aprovados**. A justificativa **universal** é o argumento integral acima, e não esses 15 ensaios.

**Observação:** a série e a fórmula da fase 4 são legítimas sob `u>0,b≥0`, mas isso não certifica automaticamente a implementação ponto fixo de cada nó.

## 5. Segunda derivada e erro do ponto médio B3

Para `f(r)=A_k(r)^2 Ω(r)/π`, vale

\[
 f''(r)=\frac{(2A_k'(r)^2+2A_k(r)A_k''(r))\Omega(r)
 +4A_k(r)A_k'(r)\Omega'(r)+A_k(r)^2\Omega''(r)}\pi.
\]

Nos intervalos próximos ao polo **removível** (`r≤6` para `k=1`, `r≤12` para `k=2`), a representação como transformada integral justifica

\[
 |A_k^{(m)}(r)|\le\int_{-L}^L|t|^m |f_k(t)|dt
 \le\frac{2\sqrt L\,L^m}{m+1},\qquad m=0,1,2.
\]

Nas faixas altas, usa-se a expressão trigonométrica dividida por `D=r²−w_k²`, com `D>0`, e as cotas obtidas diferenciando duas vezes a razão. As fronteiras escolhidas satisfazem estritamente `6>w_1` e `12>w_2`; não se deriva uma razão singular na faixa que contém `w_k`.

Com os limites `A_0,A_1,A_2,O_0,O_1,O_2` correspondentes,

\[
 M_2=\frac{(2A_1²+2A_0A_2)O_0+4A_0A_1 O_1+A_0²O_2}{\pi_{\min}}
\]

majoriza `|f''|`. A regra composta do ponto médio em `n` células de `[a,b]` obedece

\[
 \left|\int_a^b f(r)dr-h\sum_{j=0}^{n-1}f(a+(j+1/2)h)\right|
 \le M_2\frac{(b-a)^3}{24n²}.
\]

Os **11 limites de faixa** e os respectivos erros foram recalculados por uma implementação independente com `Fraction`. A correção E2 é necessária e foi preservada: o total exportado precisa majorar a soma dos **limites de banda já arredondados para cima**.

## 6. Majorante complexo de Cauchy (Fases 3 e 4)

Para `z` em qualquer disco de raio `ρ=3/10` centrado em um ponto de uma célula de largura `h=1/10`, seja `d=ρ+h/2=7/20`. Temos `|Im z|≤d`, `|z|≤|c|+2d`, e `Re(1/4±iz/2)≥α=1/4−d/2=3/40>0`; nenhuma singularidade da digama é atravessada.

Da expansão de frações parciais da digama (DLMF 5.7.6), `γ<1` e `Re u≥α>0`,

\[
 |\psi(u)|\le1+|u-1|(1+1/α).
\]

A representação integral `sinc(z)=∫_0^1 cos(tz)dt` fornece `|sinc(z)|≤e^{|Im z|}`. Usando `2Ld=63/200<1`, `e^{2Ld}≤1/(1−2Ld)`, `π>3`, `log π<2`, temos

\[
 |q_{ij}(z)|\le M(c)=\frac{4L}{3(1-2Ld)}\left[3+(1+1/α)\left(1+\frac{|c|+d}{2}\right)\right].
\]

A cota é uniforme em `i,j` de mesma paridade. O resto de interpolação polinomial, com 16 nós e fórmula real de Lagrange combinada com Cauchy para a derivada de ordem 16, é majorado por `h M(c) P_16 (h/ρ)^16`. Somando sobre 1.600 células, o novo revisor obteve, **exatamente**:

\[
 E_{\rm Cauchy}=\frac{4154891126177792}{209922127267236328125}
 \approx 1,979253535711606\cdot10^{-5}.
\]

Isto valida a dedução do **majorante** e do **erro de interpolação** para as hipóteses citadas; continua separada a verificação dos valores nodais e dos demais termos da matriz.

## 7. Lema 4 e Proposição 6: cauda infinita

A identidade da digama por reflexão e duplicação (DLMF 5.5), combinada com comparação série–integral, dá a cota, para `r≥1`,

\[
 |\Omega(r)|\le\log r+3,14.
\]

No teste racional foram confirmadas as desigualdades `3,8013<γ+3ln2+lnπ<3,8014`, `0,8047<(ln5)/2<0,8048` e `π/(2coshπ)<0,1356`. Esses números implicam a margem `Ω(r)>−3,14` e `Ω(r)<ln r−0,99`.

Para `r≥R≥max(1,2w_N)` e índices de mesma paridade,

\[
 |A_k(r)|\le\frac{2w_k}{\sqrt L(r²-w_k²)}
 \le\frac{2w_k}{\sqrt L(1-(w_k/R)^2)r²}.
\]

Integrando `r⁻⁴(log r+3,14)` obtemos a **Proposição 6**:

\[
 T_{ij}\le \frac{4w_iw_j}{\pi L(1-(w_i/R)^2)(1-(w_j/R)^2)}
 \frac{\log R+3,14+1/3}{3R³}.
\]

No novo programa, as constantes são envolvidas por racionais direcionais, as hipóteses `R≥2w_N` são checadas e `18+32+50=100` entradas de mesma paridade tiveram **meia-largura exportada superior ao majorante**. Isso **não** prova que o centro arquimediano exportado é correto.

## 8. Composição de novas inclusões para integrais completas

Usando **a soma finita B5** extraída de todos os registros pontuais, o **erro do ponto médio corrigido E2/B3** e a **cota independente de cauda da Proposição 6**, construímos

\[
 [G_{kk}]_{E7}:=[S^-_{B5}-E_{B3}-T_{\rm Prop6},\;S^+_{B5}+E_{B3}+T_{\rm Prop6}].
\]

Cada soma foi reconstituída a partir dos arquivos JSONL: a posição de cada ponto e a multiplicação intervalar pelo passo racional foram novamente verificadas, além dos hashes e da fonte original B5. Resultados aproximados para leitura (valem os racionais exatos no JSON):

| Entrada | Intervalo composto E7 (aproximado) | Contenção nas 9 referências |
|---|---|---|
| G11 | `[-1,4282431751596512; -1,4281737477533942]` | 9/9 |
| G22 | `[-0,1027780844359820; -0,1023800061201568]` | 9/9 |
| G12 | `[0;0]`, por paridade | 9/9 |

A composição é **matematicamente correta sob as hipóteses expressas**, principalmente: (H1) as identidades transcendentes e estimativas de resto acima; (H2) a classe de aritmética dirigida da B5 de fato encerra cada integrando nos pontos; (H3) os pesos e racionais são lidos sem alteração. A execução do revisor verifica vários aspectos de H2/H3, mas não constitui uma demonstração formal de todas as suas rotinas.

**Não reivindicar**: certificação de todas as matrizes, verificação independente da posição das integrais Arb de todas as entradas, ou prova da Hipótese de Riemann.

## 9. Status e pendências E7/E8

| Item | Resultado desta revisão | Aberto |
|---|---|---|
| DLMF para resto de γ, reflexões e série de ψ | Identidades e domínio positivos explicitados | Revisão matemática externa |
| Resto acelerado EM da Fase 4 | Desigualdade global derivada por coth + Laplace | Inspeção independente do código completo da Fase 4 |
| Majorantes B3 | 11 bandas, 2 entradas, testes de adulteração | Prova formal do avaliador de ponto fixo B5 |
| Majorante de Cauchy | Prova com domínio e erro de 1600 células reconstruído | Completar auditoria de todos os valores nodais |
| Proposição 6 | Prova analítica e 100 raios checados | Não basta para certificar centro Arb |
| Integrais G11 e G22 | Intervalos condicionais compostos | Ampliar a outras entradas e revisão externa |
| Proveniência | Hashes neste pacote | Assinatura pública GPG/CI real para estas novas fontes |

## 10. Fontes matemáticas externas

- NIST DLMF **5.7.6**: expansão da digama — https://dlmf.nist.gov/5.7.E6
- NIST DLMF **5.11.2, §5.11(ii)**: expansão e erro assinado para ψ em argumento real positivo — https://dlmf.nist.gov/5.11.ii
- NIST DLMF **5.5**: reflexão e duplicação — https://dlmf.nist.gov/5.5
- NIST DLMF **4.36.3**: frações parciais de coth — https://dlmf.nist.gov/4.36.E3
- Código-fonte e arquivos de resultado presentes neste ZIP, vinculados pelo `MANIFESTO_SHA256.json`.

**Parecer:** a E7 avançou da conferência numérica para uma documentação matemática explícita e uma composição racional auditável de duas integrais. A existência de provas de lemas clássicos e de verificadores racionais não elimina a necessidade de uma auditoria externa independente dos programas e da fórmula explícita global.
