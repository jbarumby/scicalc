#!/usr/bin/env python3
"""Identidades racionais do resto EM acelerado da Fase 4.
A prova universal consta no PARECER_E7.md (Laplace + coth, DLMF 4.36.3).
"""
from fractions import Fraction as Q


def b2(u,b):
    return b*b*(3*u*u+b*b)/(12*u*u*(u*u+b*b)**2)

def b4(u,b):
    return (Q(1,u**4)-(u**4-6*u*u*b*b+b**4)/(u*u+b*b)**4)/120

def laplace_moments(u,b):
    # Integral exata de t(1-cos bt)e^-ut e t^3(1-cos bt)e^-ut.
    m1=(1/u**2-(u*u-b*b)/(u*u+b*b)**2)
    m3=6*(1/u**4-(u**4-6*u*u*b*b+b**4)/(u*u+b*b)**4)
    return m1/12,m3/720

def run():
    cases=0
    for u in (Q(1,4),Q(257,4),Q(513,4)):
        for b in (Q(0),Q(1,2),Q(7),Q(80),Q(1000)):
            v2,v4=laplace_moments(u,b)
            # B2 = -g'(u)/12 = integral t(1-cos bt)e^-ut /12.
            assert b2(u,b)==v2
            assert b4(u,b)==v4
            assert v2>=0 and v4>=0
            x=b*b/(u*u)
            # (1+x)^4-(1-6x+x²)=10x+5x²+4x³+x⁴ >=0
            assert (1+x)**4-(1-6*x+x*x)==10*x+5*x*x+4*x**3+x**4
            cases+=1
    print('[E7 EM] %d/15 identidades de momentos, B2/B4 e positividade aprovadas'%cases)
    print('[E7 EM] O caso universal usa positividade do núcleo 1-cos(bt) e expansão de coth; consulte o parecer.')
    return cases

if __name__=='__main__':run()
