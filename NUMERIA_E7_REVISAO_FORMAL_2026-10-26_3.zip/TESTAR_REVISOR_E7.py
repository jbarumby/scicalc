#!/usr/bin/env python3
"""Testes negativos independentes do revisor E7, sem pacotes externos."""
import copy
import json
import tempfile
from pathlib import Path
from REVISOR_E7 import run

HOME=Path(__file__).resolve().parent


def test():
    good=run(HOME)
    assert all(good['analytic_checks'].values())
    print('[E7 TEST] pacote original aprovado')
    with tempfile.TemporaryDirectory(prefix='numeria_e7_') as tmp:
        root=Path(tmp)
        for folder in ('corrigidos','referencias_proposicao6'):
            (root/folder).mkdir()
            for fn in (HOME/folder).glob('*.json'):
                (root/folder/fn.name).write_bytes(fn.read_bytes())
        tested=0
        def expect_rejection(folder,filename,change,why):
            nonlocal tested
            f=root/folder/filename
            original=json.loads(f.read_text('utf8'))
            obj=copy.deepcopy(original)
            change(obj)
            f.write_text(json.dumps(obj),encoding='utf8')
            try:
                run(root)
            except (AssertionError,ValueError,KeyError,ZeroDivisionError):
                tested+=1
                print('[E7 TEST] alteracao rejeitada:',why)
            else:
                raise AssertionError('FALHA: adulteracao aceita: '+why)
            finally:
                f.write_text(json.dumps(original),encoding='utf8')
        f11='RESULTADO_B3_G11_E2_CORRIGIDO.json'
        f22='RESULTADO_B3_G22_E2_CORRIGIDO.json'
        f10='weil-interval-audit-v2-N10.json'
        expect_rejection('corrigidos',f11, lambda j:j['mesh'][0]['f2_absolute_bound'].update(numerator='0'), 'majorante de derivada reduzido')
        expect_rejection('corrigidos',f11, lambda j:j['quadrature_absolute_error_upper'].update(numerator='0'), 'erro total reduzido')
        expect_rejection('corrigidos',f22, lambda j:j['G22_tail_error_upper'].update(numerator='0'), 'cauda insuficiente')
        expect_rejection('corrigidos',f22, lambda j:j['mesh'][0].update(cells=1), 'malha truncada')
        expect_rejection('referencias_proposicao6',f10, lambda j:j['parameters'].update(R='1'), 'dominio R invalido')
        expect_rejection('referencias_proposicao6',f10, lambda j:j['archimedean_entry_enclosures'][0][0].update(upper='0',lower='0'), 'raio insuficiente')
    assert tested==6
    print('[E7 TEST] %d/6 alteracoes rejeitadas'%tested)

if __name__=='__main__':test()
