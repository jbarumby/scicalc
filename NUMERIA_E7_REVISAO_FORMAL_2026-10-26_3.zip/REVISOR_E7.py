#!/usr/bin/env python3
"""NUMERIA E7: revisão aritmética independente dos lemas e das cotas B3/Prop6.
Somente biblioteca padrão. Verifica CONSEQUÊNCIAS racionais de teoremas
explícitos no parecer, não prova a semântica de cada linha dos geradores.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from fractions import Fraction as Q
from pathlib import Path

L=Q(9,20); R=Q(160); U=Q(1,4); TERMS=128

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def frac(x):
    if isinstance(x,dict): return Q(int(x['numerator']),int(x['denominator']))
    return Q(x)

def arctan_bounds(x,n):
    x=Q(x)
    s=sum(((-1)**k*x**(2*k+1)/Q(2*k+1) for k in range(n)),Q(0))
    t=x**(2*n+1)/Q(2*n+1)
    return (s,s+t) if n%2==0 else (s-t,s)

def log_pos_bounds(x,terms=75):
    x=Q(x)
    if x<=0: raise ValueError('log requer x>0')
    k=0
    while x>=2: x/=2;k+=1
    while x<1: x*=2;k-=1
    t=(x-1)/(x+1)
    s=2*sum((t**(2*j+1)/Q(2*j+1) for j in range(terms)),Q(0))
    rem=2*t**(2*terms+1)/(Q(2*terms+1)*(1-t*t))
    return s,k,rem

PILA,PILB=(lambda a,b:(16*a[0]-4*b[1],16*a[1]-4*b[0]))(arctan_bounds(Q(1,5),75),arctan_bounds(Q(1,239),35))
LN2BASE=2*sum((Q(1,3)**(2*j+1)/Q(2*j+1) for j in range(95)),Q(0))
LN2=(LN2BASE,LN2BASE+2*Q(1,3)**191/(Q(191)*(1-Q(1,9))))

def log_bounds(x,terms=75):
    s,k,rem=log_pos_bounds(x,terms)
    return (s+k*LN2[0],s+rem+k*LN2[1]) if k>=0 else (s+k*LN2[1],s+rem+k*LN2[0])

def log_pi_bounds():
    lower=log_bounds(PILA,110)[0]
    upper=log_bounds(PILB,110)[1]
    return lower,upper
LNPI=log_pi_bounds(); LNR=log_bounds(R,75)

BERNOULLI=(Q(1,6),-Q(1,30),Q(1,42),-Q(1,30),Q(5,66),-Q(691,2730),Q(7,6),-Q(3617,510))

def gamma_bounds(n=64):
    if n & (n-1):raise ValueError('n precisa ser potência de 2')
    H=sum((Q(1,j) for j in range(1,n+1)),Q(0))
    k=n.bit_length()-1
    root=H-Q(1,2*n)
    corr=[BERNOULLI[j]/(2*(j+1)*n**(2*j+2)) for j in range(8)]
    top=root+sum(corr[:7]);bottom=top+corr[7]
    return bottom-k*LN2[1],top-k*LN2[0]

GAM=gamma_bounds(64)
OMEGA_ZERO=(-GAM[1]-PILB/2-3*LN2[1]-LNPI[1],-GAM[0]-PILA/2-3*LN2[0]-LNPI[0])

def omega_enclosure(r):
    """Cerca Ω(r) por série integral; endpoints racionais sem usar B3/B5."""
    r=Q(r); b2=r*r/4
    a,b=OMEGA_ZERO
    for j in range(TERMS):
        u=Q(j)+U
        q=b2/(u*(u*u+b2))
        a+=q;b+=q
    u=Q(TERMS)+U
    lin=log_bounds(1+b2/(u*u),75)
    return a+lin[0]/2,b+lin[1]/2+b2/(u*(u*u+b2))

def derivative_bounds(a,b):
    a=Q(a);b=Q(b)
    upper1=Q(0);upper2=Q(0)
    for j in range(TERMS):
        u=Q(j)+U; u2=u*u
        p=min(u*b/(2*(u2+a*a/4)**2),Q(1,3*u2))
        q=min(u*max(abs(u2-3*a*a/4),abs(u2-3*b*b/4))/(2*(u2+a*a/4)**3),Q(1,2*u**3))
        upper1+=p;upper2+=q
    u=Q(TERMS)+U
    return upper1+(1/u**2+1/u)/3, upper2+1/(2*u**3)+1/(4*u*u)

def sqrt_upper(q,digits=50):
    q=Q(q);t=10**digits
    return Q(math.isqrt(q.numerator*t*t//q.denominator)+1,t)
def sqrt_lower(q,digits=50):
    q=Q(q);t=10**digits
    return Q(math.isqrt(q.numerator*t*t//q.denominator),t)

SQRTL_H=sqrt_upper(L);SQRTL_L=sqrt_lower(L)

def m2_bound(k,a,b):
    a=Q(a);b=Q(b)
    o=max(max(abs(q) for q in omega_enclosure(a)),max(abs(q) for q in omega_enclosure(b)))
    o1,o2=derivative_bounds(a,b)
    threshold=6 if k==1 else 12
    if b<=threshold:
        F0=2*SQRTL_H
        F1=SQRTL_H*L
        F2=Q(2,3)*SQRTL_H*L*L
    else:
        if a<threshold:raise ValueError('faixa atravessa a região não regularizada')
        w2=k*k*PILB*PILB/(4*L*L)
        D=a*a-w2
        if D<=0:raise ValueError('D não positivo')
        C=k*PILB/(L*SQRTL_L)
        F0=C/D
        F1=C*(L/D+2*b/D**2)
        F2=C*(L*L/D+4*L*b/D**2+2/D**2+8*b*b/D**3)
    return ((2*F1*F1+2*F0*F2)*o+4*F0*F1*o1+F0*F0*o2)/PILA

def tail_b3(k):
    w2=k*k*PILB*PILB/(4*L*L)
    K=1-w2/(R*R)
    if K<=0:raise ValueError('cauda sem denominador positivo')
    return k*k*PILB*(6+LNR[1]+Q(1,3))/(3*L**3*R**3*K**2)

def tail_prop6(i,j):
    wi2=i*i*PILB*PILB/(4*L*L*R*R)
    wj2=j*j*PILB*PILB/(4*L*L*R*R)
    if max(wi2,wj2)>Q(1,4): raise ValueError('hipótese R >= 2 wmax falha')
    return i*j*PILB*(LNR[1]+Q(314,100)+Q(1,3))/(3*L**3*R**3*(1-wi2)*(1-wj2))

def analytic_checks():
    checks={}
    # Teorema clássico DLMF, resto assinado para psi em eixo real positivo.
    checks['pi_3_a_4']=PILA>3 and PILB<4
    checks['gamma_0_a_1']=GAM[0]>0 and GAM[1]<1
    checks['omega0_maior_menos6']=OMEGA_ZERO[0]>-6
    # q''(r) = (1-3t)/(2u^3(1+t)^3): para t>=0 verificar decomposição por casos.
    checks['derivada2_polynomial_case_left']=all(c>=0 for c in (0,6,3,1))  # 6t+3t²+t³
    checks['derivada2_polynomial_case_right']=all(c>=0 for c in (2,0,3,1))  # 2+3t²+t³
    checks['derivada1_max_9_por_16_sqrt3']=729<768
    checks['sinal_gamma_B16_negativo']=BERNOULLI[7]<0
    # B3: L=0.45, polos removíveis dentro das faixas baixas.
    checks['faixas_altas_longe_dos_polos']=Q(6)>PILB/(2*L) and Q(12)>PILB/L
    # Lema 4: C = gamma+3 ln2 + ln pi; S(r) integral lower 0.5 log5.
    C_lo=GAM[0]+3*LN2[0]+LNPI[0]; C_hi=GAM[1]+3*LN2[1]+LNPI[1]
    log5_lo,log5_hi=log_bounds(5,80)
    cosh_low=sum((PILA**(2*j)/math.factorial(2*j) for j in range(7)),Q(0))
    checks['lema4_constante']=Q('3.8013')<C_lo<=C_hi<Q('3.8014')
    checks['lema4_log5']=Q('0.8047')<log5_lo/2<=log5_hi/2<Q('0.8048')
    checks['lema4_cosh']=PILB/(2*cosh_low)<Q('0.1356')
    # (-C + log5/2 - sech) > -3.14;
    checks['lema4_lower']= -C_hi + log5_lo/2 - PILB/(2*cosh_low) > -Q(314,100)
    checks['lema4_upper']= -C_lo + 2+log5_hi/2 < -Q(99,100)
    # Maiorante complexo da fase 3/4 para L=.45,h=.1,rho=.3.
    h=Q(1,10);rho=Q(3,10);d=rho+h/2;alpha=Q(1,4)-d/2
    checks['cauchy_hipoteses']=d<Q(1,2) and alpha>0 and 2*L*d<1
    checks['cauchy_alpha_3_40']=alpha==Q(3,40)
    # 1600 células / 16 nós: verificação EXATA da soma da cota de Cauchy da Fase 3/4.
    m=16
    prod=Q(1)
    for j in range(m):
        u=Q(j,m-1)
        prod*=max(u,1-u)
    factor=h*prod*(h/rho)**m
    actual=sum((factor*(4*L/(3*(1-2*L*d)))*(
            3+(1+1/alpha)*(1+(Q(2*c+1,20)+d)/2)) for c in range(1600)),Q(0))
    checks['cauchy_erro_1600_celulas']=actual==Q(4154891126177792,209922127267236328125)
    return checks

def inspect_b3(path,k):
    d=json.loads(Path(path).read_text('utf8'))
    if (k==1 and d.get('schema')!='NUMERIA.B3.G11.RATIONAL.1') or (k==2 and d.get('schema')!='NUMERIA.B3.G12G22.RATIONAL.1'):
        raise ValueError('schema não corresponde à entrada')
    mesh=d['mesh'];pos=Q(0);npoints=0;errsum=Q(0)
    for band in mesh:
        a,b,n=Q(band['from']),Q(band['to']),int(band['cells'])
        if a!=pos or b<=a or n<1: raise AssertionError('malha inválida')
        pos=b;npoints+=n
        M=m2_bound(k,a,b)
        declared_m=frac(band['f2_absolute_bound'] if k==1 else band['f2_bound'])
        declared_err=frac(band['midpoint_error_bound'] if k==1 else band['error_bound'])
        actual_err=M*(b-a)**3/(24*n*n)
        if not (declared_m>=M and declared_err>=actual_err):
            raise AssertionError(f'cota por faixa menor que fórmula derivada, {a}-{b}')
        errsum+=declared_err
    if pos!=R or npoints!={1:9524,2:6230}[k]:raise AssertionError('malha/tamanho divergentes')
    e=frac(d['quadrature_absolute_error_upper'] if k==1 else d['G22_quadrature_error_upper'])
    tail=frac(d['tail_absolute_error_upper'] if k==1 else d['G22_tail_error_upper'])
    if e<errsum:raise AssertionError('erro total é menor que a soma das cotas exportadas')
    if tail<tail_b3(k):raise AssertionError('cota de cauda é insuficiente')
    totals=[frac(v) for v in (d['g11_independent_enclosure'] if k==1 else d['G22_enclosure'])]
    sums=[frac(v) for v in (d['finite_midpoint_sum_enclosure'] if k==1 else d['G22_fixed_point_midpoint'])]
    if totals[0]>sums[0]-e-tail or totals[1]<sums[1]+e+tail:
        raise AssertionError('intervalo final não contém somatório ± erros')
    return {'entry':f'G{k}{k}','points':npoints,'bands':len(mesh), 'strict_enclosure':True,
            'error_total_upper':str(e),'tail_upper':str(tail),
            'source_sha256':sha(path)}

def inspect_prop6(path):
    d=json.loads(Path(path).read_text('utf8'))
    params=d['parameters'];N=int(params['N']); R0=Q(params['R']);L0=Q(params['L'])
    if R0!=R or L0!=L or params.get('tail_bound')!='lemma5' or N not in (6,8,10):
        raise AssertionError('parâmetros do certificado não correspondem à prova')
    if R < N*PILB/L:raise AssertionError('R < 2wmax')
    G=d['archimedean_entry_enclosures'];cnt=0;min_slack=None
    for i in range(1,N+1):
        for j in range(1,N+1):
            t=G[i-1][j-1];lo,hi=Q(t['lower']),Q(t['upper'])
            if (i-j)%2:
                if lo!=0 or hi!=0:raise AssertionError('paridade impossível')
                continue
            half=(hi-lo)/2
            theoretical=tail_prop6(i,j)
            if half<theoretical:raise AssertionError(f'raio de G{i}{j} menor que a cauda')
            slack=half-theoretical
            min_slack=slack if min_slack is None else min(min_slack,slack)
            cnt+=1
    return {'N':N,'entries_same_parity':cnt,'minimal_slack_approx':f'{float(min_slack):.16g}',
            'source_sha256':sha(path)}

def run(root):
    root=Path(root)
    assertions=analytic_checks()
    if not all(assertions.values()): raise AssertionError('falha em identidades/constantes: '+repr([k for k,v in assertions.items() if not v]))
    b3=[inspect_b3(root/'corrigidos'/name,k) for name,k in [('RESULTADO_B3_G11_E2_CORRIGIDO.json',1),('RESULTADO_B3_G22_E2_CORRIGIDO.json',2)]]
    prop=[inspect_prop6(root/'referencias_proposicao6'/f'weil-interval-audit-v2-N{n}.json') for n in (6,8,10)]
    return {'status':'APROVADO_SOB_IDENTIDADES_MATEMATICAS_EXPLICITADAS','date':'2026-10-26',
            'analytic_checks':assertions,'b3':b3,'prop6':prop,
            'limits':['O script valida consequências racionais das identidades, mas não formaliza os teoremas DLMF.',
                'Raio maior que cauda não comprova posição do centro Arquimediano.',
                'Não verifica todas as entradas nem a fórmula explícita global.']}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--out',type=Path)
    a=parser.parse_args();out=run(a.root)
    if a.out:
        a.out.parent.mkdir(parents=True,exist_ok=True)
        a.out.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n','utf8')
    print('[E7] Checagens analíticas:',len(out['analytic_checks']), '/',len(out['analytic_checks']))
    for d in out['b3']:print('[E7]',d['entry'],d['points'],'pontos;',d['bands'],'faixas, erros e cauda OK')
    for d in out['prop6']:print('[E7] N=%d: %d raios de cauda conferidos'%(d['N'],d['entries_same_parity']))
    print('[E7] STATUS:',out['status'])
    return 0

if __name__=='__main__':raise SystemExit(main())
