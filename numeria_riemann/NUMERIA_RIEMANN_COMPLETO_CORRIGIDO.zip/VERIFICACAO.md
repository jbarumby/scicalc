# Auditoria NUMERIA–RIEMANN — execução

Instale `python-flint==0.9.0` em Python 3.11.

```bash
python -m py_compile numeria_riemann/weil_interval_audit.py
python -m unittest numeria_riemann.test_weil_interval_audit -v
python -m numeria_riemann.weil_interval_audit --L 0.45 --N 6 --R 160 --step 0.02 --series-terms 128 --precision 192 --out weil-interval-audit-N6.json
python -m numeria_riemann.weil_interval_audit --L 0.45 --N 8 --R 160 --step 0.01 --series-terms 256 --precision 256 --out weil-interval-audit-N8.json
python -m numeria_riemann.weil_interval_audit --L 0.45 --N 10 --R 160 --step 0.01 --series-terms 256 --precision 256 --out weil-interval-audit-N10.json
```

A execução do módulo requer a presença de `run` e `main`; o teste fica em arquivo separado. O código não deve conter `unittest.main()` em `weil_interval_audit.py`.

Verifique nos JSON: `status`, `interval_ldl_pivot_lower_bounds`, `parameters`, e `limitations`. Um job verde confirma execução, não certificação matemática independente. Não confundir positividade finita com RH.

A sintaxe e a presença das funções foram verificadas localmente. A instalação e os cálculos Arb não foram reproduzidos neste ambiente.
