"""Run: python -m unittest numeria_riemann.test_weil_interval_audit -v"""
import unittest
from flint import arb
from numeria_riemann.weil_interval_audit import _interval_ldl_pivots

class TestIntervalLDL(unittest.TestCase):
    def test_positive(self):
        pivots, ok = _interval_ldl_pivots([[arb(2),arb(0)],[arb(0),arb(3)]])
        self.assertTrue(ok)
        self.assertEqual(len(pivots),2)

    def test_inconclusive(self):
        _, ok = _interval_ldl_pivots([[arb('0 +/- 1'),arb(0)],[arb(0),arb(3)]])
        self.assertFalse(ok)

    def test_export_bounds(self):
        p = arb('0.3 +/- 0.1')
        self.assertTrue(p.lower() > 0)
        self.assertTrue(p.upper() > p.lower())
        self.assertTrue(p.lower() <= p)
        self.assertTrue(p <= p.upper())
        self.assertIsInstance(p.lower().str(40, radius=False),str)

if __name__ == '__main__':
    unittest.main()
