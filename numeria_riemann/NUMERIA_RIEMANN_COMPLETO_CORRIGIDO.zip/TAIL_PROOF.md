# Fase 6 — prova de uma cota conservadora para a cauda arquimediana

Esta nota prova **somente** a cota da cauda para a expressão `Omega` e a amplitude `F_k` tal como definidas no código. Não prova que a fórmula de Weil, os sinais, a projeção ou as restrições de polos estejam corretos.

Para `r >= 0`, ponha `f_r(y)=r²/[y(y²+r²)]`, `y>0`. A série usada no código é

`Omega(r) = -gamma - 3 log 2 - log pi + sum_{n>=0} f_r(n+1/2) - pi/[2 cosh(pi r)]`.

**Passo 1.** `f_r(y)` é não negativa e decrescente em `y` (para `r=0` é identicamente zero). Pelo teste integral,

`0 <= sum_{n>=0} f_r(n+1/2) <= f_r(1/2) + integral_{1/2}^infty f_r(y) dy`.

O primeiro termo é `<=2`. Por integração direta, a integral é `(1/2) log(1+4r²) <= log(1+2r)`. Como `0 <= pi/[2 cosh(pi r)] <= pi/2`, obtemos

`-gamma - 3 log 2 - log pi - pi/2 <= Omega(r) <= 2+log(1+2r)`.

**Atenção:** o limite inferior acima é **mais negativo que -6**; portanto a afirmação simplificada `|Omega| <= 6+log(1+2r)` não segue dessa estimativa. Para evitar essa lacuna, usamos a cota segura `|Omega(r)| <= 8+log(1+2r)`: de `gamma<1`, `log 2<1`, `log pi<2`, `pi/2<2`, o módulo do limite inferior é menor que `1+3+2+2=8`; o limite superior é menor que `8+log(1+2r)`.

**Passo 2.** Para `r>=1`, `1+2r <=3r`, portanto `|Omega(r)| <= 8+log(3r)`.

**Passo 3.** Com `w_k=k*pi/(2L)` e a amplitude implementada `F_k(r)=2 sqrt(L) w_k/(w_k+r) sinc(L(r-w_k))` (a fase complexa tem módulo 1), se `r>=2 w_max`, então `|sinc(x)| <=1/|x|` e

`|F_k(r)| <= 2 w_k/[sqrt(L) (r+w_k)(r-w_k)] <= (8/3) w_k/[sqrt(L) r²] <= 4 w_k/[sqrt(L) r²]`.

**Passo 4.** Para `R>=max(1,2w_max)`, por multiplicação das cotas,

`|(1/pi) integral_R^infty Re(F_i conj(F_j)) Omega(r) dr| <= [16 w_i w_j/(pi L)] * integral_R^infty [8+log(3r)]/r^4 dr`

`= [16 w_i w_j/(pi L)] * [8+log(3R)+1/3]/(3 R³)`.

Esse valor é um raio **conservador** de inclusão da cauda. O código usa `arb(0, tail)` e deve verificar que o construtor contém ambos os extremos.

## Limitações

1. A prova vale para a definição explícita de `Omega` no código; conferir separadamente a identidade com a digama.
2. A cota é mais frouxa que a fórmula anterior baseada em Binet; uma certificação positiva anterior pode ficar inconclusiva.
3. Nenhuma execução Arb foi realizada nesta fase se `python-flint` estiver ausente.
4. Os limites para integrais sobre células, sobreposições de primos e constraints exigem auditoria separada.
